
public class NfaPair {
    public Nfa startNode;
    public Nfa endNode;
}
