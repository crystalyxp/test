import java.io.InputStream;


public class DiskFileHandler implements FileHandler{
	
	public DiskFileHandler(String name) {
		
	}

	public void Open() {
		
	}
	
	public int Close() {
		return 0;
	}
	
	public int Read( byte[] buf, int begin, int len) {
		return 0;
	}
}
